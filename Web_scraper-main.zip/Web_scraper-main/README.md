# Web_scraper

There are 2 files in here.

The scraper file gives an idea about the basics of scraping.

The webpage used for it : https://coreyms.com/

The scraper_project goes deeper into the scraping part. It is divided into 2 parts:

The first part being scraping the simple webpage, the link for it is : https://keithgalli.github.io/web-scraping/example.html

The second part being scraping the webpage and answering questions, the link for it is : https://keithgalli.github.io/web-scraping/webpage.html

The video links for them are as follows and credit to the respective creators:
https://www.youtube.com/watch?v=ng2o98k983k
https://youtu.be/GjKQ6V_ViQE
